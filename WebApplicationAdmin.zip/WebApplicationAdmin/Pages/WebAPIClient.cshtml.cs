using Microsoft.AspNetCore.Mvc.RazorPages;
using WebApplicationAdmin.API;
using WebAPI.Entities;

namespace WebApplicationAdmin.Pages
{
    public class WebAPIClientModel : PageModel
    {
        private readonly IApiInterface _apiService;

        public List<Refuel> Refuels { get; private set; }

        public WebAPIClientModel(IApiInterface apiService)
        {
            _apiService = apiService;
        }

        public async Task OnGetAsync()
        {
            Refuels = await _apiService.GetAllRefuels();
        }
    }
}